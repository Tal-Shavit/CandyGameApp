package com.example.hw1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment_Map extends Fragment {

    protected View view;
    //private EditText records_TXT_map;

    public static Fragment_Map newInstance() {
        Fragment_Map fragment_map = new Fragment_Map();
        return fragment_map;
    }
    

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if(view==null)
            view = inflater.inflate(R.layout.fragment_map, container, false);
        
        findViews(view);
        //setMap("lplplp");

        return view;
    }

    private void findViews(View view) {
        //records_TXT_map = view.findViewById(R.id.records_TXT_map);
    }

    public void setMap(String location){
        //records_TXT_map.setText(location);

    }


}