package com.example.hw1;

public interface CallBack_Location {
    void locationReady(double log, double lat);
}
