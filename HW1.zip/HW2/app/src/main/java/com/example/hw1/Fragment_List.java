package com.example.hw1;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class Fragment_List extends Fragment {

    /*public static final String KEY_SCORE = "KEY_SCORE";
    public static String KEY_NAME = "KEY_NAME";*/

    //private TextView fragmentList_LBL_name;
    //private TextView fragmentList_LBL_score;
    private DataBase newDb2;
    private RecyclerView fragmentList_RV_records;
    private UserItems userItems;

    protected View view;
    private ArrayList<UserItems> userItemsArrayList = new ArrayList<>();
    private ArrayList<String> names = new ArrayList<>();
    private ArrayList<Integer> scores = new ArrayList<>();

    public static Fragment_List newInstance() {
        Fragment_List fragment_list = new Fragment_List();
        return fragment_list;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
       return view = inflater.inflate(R.layout.fragment_list, container, false);
        //if (view == null)
         //   view = inflater.inflate(R.layout.fragment_list, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
       /* if (view == null)
            view = inflater.inflate(R.layout.fragment_list, container, false);*/

        dataInitialize();
        findViews(view);

        fragmentList_RV_records.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        fragmentList_RV_records.setHasFixedSize(true);
        RecorsAdapter recAdapter = new RecorsAdapter(getContext(),userItemsArrayList);
        //Log.d("LALA", "rec = "+recAdapter.userItemsArrayList.size());
        fragmentList_RV_records.setAdapter(recAdapter);
        recAdapter.notifyDataSetChanged();

    }


    /*@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null)
            view = inflater.inflate(R.layout.fragment_list, container, false);

        dataInitialize();
        findViews(view);

        fragmentList_RV_records.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        fragmentList_RV_records.setHasFixedSize(true);
        RecorsAdapter recAdapter = new RecorsAdapter(getContext(),userItemsArrayList);
        fragmentList_RV_records.setAdapter(recAdapter);
        recAdapter.notifyDataSetChanged();

        return view;
    }*/

    private void dataInitialize() {
        String fromJSON2 = MySP.getInstance(getContext()).getStringSP("MY_DB","");
        newDb2 = new Gson().fromJson(fromJSON2,DataBase.class);

        if(newDb2 == null){
            newDb2 = new DataBase();
        }

        if(newDb2 != null){
            for (int i = 0; i < newDb2.getUserItems().size(); i++) {
                Log.d("LALA", i + " = "+newDb2.getUserItems().get(i).getName());
                names.add(newDb2.getUserItems().get(i).getName());
                scores.add(newDb2.getUserItems().get(i).getScore());
                userItems = new UserItems(names.get(i),scores.get(i));
                userItemsArrayList.add(userItems);
                Log.d("LALA",""+userItemsArrayList.size());
            }
        }

    }


    private void findViews(View view) {
        //fragmentList_LBL_name = view.findViewById(R.id.fragmentList_LBL_name);
        //fragmentList_LBL_score = view.findViewById(R.id.fragmentList_LBL_score);
        fragmentList_RV_records = view.findViewById(R.id.fragmentList_RV_records);
    }

}

