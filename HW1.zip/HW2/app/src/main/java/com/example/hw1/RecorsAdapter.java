package com.example.hw1;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecorsAdapter extends RecyclerView.Adapter<RecorsAdapter.MyViewHolder> {

    Context context;
    ArrayList<UserItems> userItemsArrayList;

    public RecorsAdapter(Context context, ArrayList<UserItems> userItemsArrayList) {
        this.context = context;
        this.userItemsArrayList = userItemsArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_list_items, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Log.d("LALA","pos = "+position);
        UserItems userItems = userItemsArrayList.get(position);
        holder.fragmentList_LBL_name.setText(userItems.getName());
        holder.fragmentList_LBL_score.setText(""+userItems.getScore());
    }

    @Override
    public int getItemCount() {
        return userItemsArrayList.size();
    }

    public static class  MyViewHolder extends RecyclerView.ViewHolder{

        TextView fragmentList_LBL_score;
        TextView fragmentList_LBL_name;

        public MyViewHolder(@NonNull View itemView){
            super((itemView));
            fragmentList_LBL_name = itemView.findViewById(R.id.fragmentList_LBL_name);
            fragmentList_LBL_score = itemView.findViewById(R.id.fragmentList_LBL_score);
        }
    }
    /*private ArrayList<UserItems> userItems = new ArrayList<>();

    public RecorsAdapter(ArrayList<UserItems> userItems) {
        this.userItems = userItems;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_list,parent,false);
        return new RecordsViewHolde(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        RecordsViewHolde recordsViewHolde = (RecordsViewHolde) holder;
        UserItems userItems = getItems(position);

        recordsViewHolde.fragmentList_LBL_name.setText(userItems.getName());
        recordsViewHolde.fragmentList_LBL_score.setText(userItems.getScore());
    }

    @Override
    public int getItemCount() {
        return userItems.size();
    }

    private UserItems getItems(int position){
        return userItems.get(position);
    }

    public class RecordsViewHolde extends RecyclerView.ViewHolder{
        private TextView fragmentList_LBL_score;
        private TextView fragmentList_LBL_name;

        public RecordsViewHolde(@NonNull View itemView) {
            super(itemView);
            fragmentList_LBL_name = itemView.findViewById(R.id.fragmentList_LBL_name);
            fragmentList_LBL_score = itemView.findViewById(R.id.fragmentList_LBL_score);
        }
    }*/
}
