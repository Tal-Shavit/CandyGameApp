package com.example.hw1;

import java.util.ArrayList;

public class DataBase {
    private ArrayList<UserItems> userItems = new ArrayList<>();

    public DataBase(){

    }

    public ArrayList<UserItems> getUserItems() {
        return userItems;
    }

    public DataBase setUserItems(ArrayList<UserItems> userItems) {
        this.userItems = userItems;
        return this;
    }
}
