# HW1

# Game instructions
You are a mouth and need to escape from the poisons.
If you ate a poison you lose a life.

# How To Play
Move left and right to avoid a poison

# Video
https://user-images.githubusercontent.com/117349966/205010824-fbade2e6-9a46-42ce-983c-7904b889907e.mp4

